/**
 * 
 */
package juegoDomino;

/**
 * @author Usser
 *
 */
public class ControlDomino {
	private int juega ;
	
	
}
