/**
 * 
 */
package juegoDomino;

/**
 * @author Usser
 *
 */
public class PrincipalDomino {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FichasDomino asd = new FichasDomino();
	
		//asd.obtener();
		for(int i =0;i<28;i++) {
			System.out.println(asd.getarray(i));
			}
	}
	String caminos(int[][] variable) {
		return "a";
	}

}
