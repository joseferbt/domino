/**
 * 
 */
package juegoDomino;

import java.util.ArrayList;

/**
 * @author Usser
 *
 */
public class UsuarioDomino {
	private ArrayList<int[]> fichas;
	private int dinero;
	
	public UsuarioDomino(int dinero, ArrayList<int[]> fichas){
		this.dinero = dinero;
		this.fichas = fichas;
	}
	
	
	
}
